-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 08, 2021 at 09:25 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `projet5-blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `content` text NOT NULL,
  `validation_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `id_user`, `id_post`, `created_at`, `content`, `validation_status`) VALUES
(1, 6, 1, '2021-01-07 21:50:00', 'id labore ex et quam laborum', 1),
(2, 5, 1, '2021-02-01 13:26:56', 'quo vero reiciendis velit similique earum', 1),
(3, 3, 1, '2021-02-08 13:26:56', 'odio adipisci rerum aut animi', 1),
(5, 4, 2, '2021-02-09 10:17:23', 'alias odio sit', 1),
(6, 5, 2, '2021-02-09 10:17:30', 'vero eaque aliquid doloribus et culpa', 1),
(7, 6, 2, '2021-02-09 09:26:17', 'et fugit eligendi deleniti quidem qui sint nihil autem', 1),
(8, 6, 3, '2021-02-09 10:16:07', 'repellat consequatur praesentium vel minus molestias voluptatum', 1),
(9, 2, 3, '2021-02-09 10:16:18', 'et omnis dolorem', 1),
(10, 3, 3, '2021-02-09 11:16:55', 'provident id voluptas', 1),
(11, 4, 4, '2021-02-10 11:15:10', 'eaque et deleniti atque tenetur ut quo ut', 0),
(13, 5, 4, '2021-02-10 11:34:56', 'fugit labore quia mollitia quas deserunt nostrum sunt', 0),
(14, 6, 4, '2021-02-10 11:39:48', 'modi ut eos dolores illum nam dolor', 0),
(21, 6, 1, '2021-02-26 17:50:50', 'sed impedit rerum quia et et inventore unde officiis', 0),
(22, 2, 2, '2021-02-27 10:09:35', 'molestias expedita iste aliquid voluptates', 0),
(23, 3, 3, '2021-02-27 10:15:55', 'aliquid rerum mollitia qui a consectetur eum sed', 0);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `short_description` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `id_user`, `title`, `created_at`, `updated_at`, `short_description`, `content`) VALUES
(1, 1, 'Eum et est occaecati', '2021-01-01 22:51:23', '2021-03-08 17:13:11', 'eos dolorem iste accusantium est eaque quam', 'aut dicta possimus sint mollitia voluptas commodi quo doloremque\\niste corrupti reiciendis voluptatem eius rerum\\nsit cumque quod eligendi laborum minima\\nperferendis recusandae assumenda consectetur porro architecto ipsum ipsam'),
(2, 1, 'Qui est esse', '2021-01-02 00:20:32', '2021-03-04 21:05:32', 'sunt aut facere repellat provident occaecati excepturi optio reprehenderit', 'est rerum tempore vitae\\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\\nqui aperiam non debitis possimus qui neque nisi nulla'),
(3, 2, 'Nesciunt quas odio', '2021-01-03 18:41:06', '2021-03-04 21:00:07', 'ea molestias quasi exercitationem repellat qui ipsa sit aut', 'ullam et saepe reiciendis voluptatem adipisci\\nsit amet autem assumenda provident rerum culpa\\nquis hic commodi nesciunt rem tenetur doloremque ipsam iure\\nquis sunt voluptatem rerum illo velit'),
(4, 2, 'Magnam facilis autem', '2021-01-04 11:30:10', '2021-03-08 21:08:07', 'id nihil consequatur molestias animi provident', 'ut aspernatur corporis harum nihil quis provident sequi\\nmollitia nobis aliquid molestiae\\nperspiciatis et ea nemo ab reprehenderit accusantium quas\\nvoluptate dolores velit et doloremque molestiae'),
(6, 2, 'Aut amet sed', '2021-03-02 21:05:36', '2021-03-04 21:05:36', 'quaerat velit veniam amet cupiditate aut numquam ut sequi', 'libero voluptate eveniet aperiam sed\\nsunt placeat suscipit molestias\\nsimilique fugit nam natus\\nexpedita consequatur consequatur dolores quia eos et placeat'),
(7, 1, 'Laboriosam dolor voluptates', '2021-03-06 21:05:36', '2021-03-08 21:08:15', 'quas fugiat ut perspiciatis vero provident', 'eum non blanditiis soluta porro quibusdam voluptas\\nvel voluptatem qui placeat dolores qui velit aut\\nvel inventore aut cumque culpa explicabo aliquid at\\nperspiciatis est et voluptatem dignissimos dolor itaque sit nam');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin_status` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `pseudo`, `name`, `firstname`, `email`, `password`, `admin_status`, `created_at`) VALUES
(1, 'admin-A', 'Dessart', 'Maheva', 'admin@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 1, '2021-02-03 22:04:16'),
(2, 'admin-B', 'Dess', 'Mahe', 'admin2@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 1, '2021-02-25 21:49:09'),
(3, 'Ervin24', 'Ervin', 'Howell', 'user-a@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 0, '2021-02-25 21:52:01'),
(4, 'Patricia90', 'Patricia', 'Lebsack', 'user-b@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 0, '2021-02-25 21:52:21'),
(5, 'Kamren87', 'Chelsey', 'Dietrich', 'user-c@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 0, '2021-02-25 22:03:52'),
(6, 'Dennis44', 'Dennis', 'Schulist', 'user-d@gmail.com', '$2y$10$GIUS4oOX2hH87uARPxBwwOI9m42BNK4LONa9Gvsi14Q5vkBpCGWbu', 0, '2021-02-25 23:48:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_FK` (`id_post`),
  ADD KEY `user_FK2` (`id_user`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_FK` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `post_FK` FOREIGN KEY (`id_post`) REFERENCES `posts` (`id`),
  ADD CONSTRAINT `user_FK2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `user_FK` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);
